// Translation system for WatAlsHetWelKan One-Page Video Request
const translations = {
    en: {
        // Header
        logo: "WatAlsHetWelKan",
        
        // Hero Section
        hero_title_1: "Turn your idea into",
        hero_title_2: "stunning AI videos",
        hero_subtitle: "Create professional AI-generated videos from simple text prompts. Powered by advanced VEO 3 technology.",
        
        // Video Preview
        demo_text: "Your AI video will appear here",
        
        // Form
        form_title: "Create Your AI Video",
        form_subtitle: "Enter your creative idea and email address to get started",
        
        // Form Fields
        video_language: "Video Language:",
        email_label: "Your Email Address:",
        email_placeholder: "your.email@example.com",
        prompt_label: "Video Description:",
        prompt_placeholder: "A 90s-style trailer of a robot uprising in a futuristic city with dramatic lighting and epic music...",
        prompt_help: "Be creative and descriptive for best results",
        
        // Language Options
        english: "English",
        french: "Français",
        
        // Submit Button
        submit_button: "🎬 Send Video Request",
        sending: "Sending",
        
        // Messages
        success_title: "Request Sent Successfully!",
        success_message: "We've received your video request. Our team will contact you via email within 24 hours with your custom AI video.",
        error_title: "Something went wrong",
        error_message: "Please try again or contact support if the problem persists.",
        
        // Features
        feature_1_title: "Lightning Fast",
        feature_1_desc: "Get your custom AI video within 24 hours",
        feature_2_title: "Professional Quality", 
        feature_2_desc: "Powered by cutting-edge VEO 3 AI technology",
        feature_3_title: "Personal Support",
        feature_3_desc: "Direct communication throughout the process",
        
        // Footer
        footer_text: "© 2024 WatAlsHetWelKan. Transforming ideas into reality.",
        
        // Validation Messages
        email_required: "Please enter your email address",
        email_invalid: "Please enter a valid email address", 
        prompt_required: "Please enter a video description",
        prompt_too_short: "Description must be at least 20 characters",
        prompt_too_long: "Description cannot exceed 500 characters",
        
        // EmailJS Messages
        emailjs_success: "Your video request has been sent successfully! We'll be in touch soon.",
        emailjs_error: "Failed to send your request. Please try again.",
        emailjs_network_error: "Network error. Please check your connection and try again."
    },
    
    fr: {
        // Header
        logo: "WatAlsHetWelKan",
        
        // Hero Section
        hero_title_1: "Transformez votre idée en",
        hero_title_2: "vidéos IA époustouflantes",
        hero_subtitle: "Créez des vidéos professionnelles générées par IA à partir de simples prompts texte. Alimenté par la technologie avancée VEO 3.",
        
        // Video Preview
        demo_text: "Votre vidéo IA apparaîtra ici",
        
        // Form
        form_title: "Créez Votre Vidéo IA",
        form_subtitle: "Entrez votre idée créative et votre adresse e-mail pour commencer",
        
        // Form Fields
        video_language: "Langue de la Vidéo:",
        email_label: "Votre Adresse E-mail:",
        email_placeholder: "votre.email@exemple.com",
        prompt_label: "Description de la Vidéo:",
        prompt_placeholder: "Une bande-annonce des années 90 d'un soulèvement de robots dans une ville futuriste avec un éclairage dramatique et une musique épique...",
        prompt_help: "Soyez créatif et descriptif pour de meilleurs résultats",
        
        // Language Options
        english: "Anglais",
        french: "Français",
        
        // Submit Button
        submit_button: "🎬 Envoyer la Demande Vidéo",
        sending: "Envoi en cours",
        
        // Messages
        success_title: "Demande Envoyée avec Succès!",
        success_message: "Nous avons reçu votre demande de vidéo. Notre équipe vous contactera par e-mail dans les 24 heures avec votre vidéo IA personnalisée.",
        error_title: "Quelque chose s'est mal passé",
        error_message: "Veuillez réessayer ou contacter le support si le problème persiste.",
        
        // Features
        feature_1_title: "Ultra Rapide",
        feature_1_desc: "Obtenez votre vidéo IA personnalisée dans les 24 heures",
        feature_2_title: "Qualité Professionnelle",
        feature_2_desc: "Alimenté par la technologie de pointe VEO 3 IA",
        feature_3_title: "Support Personnel",
        feature_3_desc: "Communication directe tout au long du processus",
        
        // Footer
        footer_text: "© 2024 WatAlsHetWelKan. Transformant les idées en réalité.",
        
        // Validation Messages
        email_required: "Veuillez entrer votre adresse e-mail",
        email_invalid: "Veuillez entrer une adresse e-mail valide",
        prompt_required: "Veuillez entrer une description vidéo",
        prompt_too_short: "La description doit contenir au moins 20 caractères",
        prompt_too_long: "La description ne peut pas dépasser 500 caractères",
        
        // EmailJS Messages
        emailjs_success: "Votre demande de vidéo a été envoyée avec succès! Nous vous contacterons bientôt.",
        emailjs_error: "Échec de l'envoi de votre demande. Veuillez réessayer.",
        emailjs_network_error: "Erreur réseau. Veuillez vérifier votre connexion et réessayer."
    }
};

class TranslationManager {
    constructor() {
        this.currentLanguage = localStorage.getItem('selectedLanguage') || 'en';
        this.init();
    }
    
    init() {
        // Set initial language
        this.setLanguage(this.currentLanguage);
        
        // Add event listener for language selector
        const languageSelector = document.getElementById('languageSelector');
        if (languageSelector) {
            languageSelector.value = this.currentLanguage;
            languageSelector.addEventListener('change', (e) => {
                this.setLanguage(e.target.value);
            });
        }
    }
    
    setLanguage(lang) {
        this.currentLanguage = lang;
        localStorage.setItem('selectedLanguage', lang);
        
        // Update HTML lang attribute
        document.documentElement.lang = lang;
        
        // Update language selector
        const languageSelector = document.getElementById('languageSelector');
        if (languageSelector) {
            languageSelector.value = lang;
        }
        
        // Translate all elements
        this.translatePage();
        
        // Update placeholders
        this.updatePlaceholders();
        
        // Update radio button selection based on language
        this.updateVideoLanguageRadios();
        
        // Trigger custom event for other components
        window.dispatchEvent(new CustomEvent('languageChanged', { detail: { language: lang } }));
    }
    
    translatePage() {
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            const translation = this.getTranslation(key);
            if (translation) {
                element.textContent = translation;
            }
        });
    }
    
    updatePlaceholders() {
        const elements = document.querySelectorAll('[data-translate-placeholder]');
        elements.forEach(element => {
            const key = element.getAttribute('data-translate-placeholder');
            const translation = this.getTranslation(key);
            if (translation) {
                element.placeholder = translation;
            }
        });
    }
    
    updateVideoLanguageRadios() {
        // Auto-select video language radio based on interface language
        const videoLangRadios = document.querySelectorAll('input[name="videoLanguage"]');
        videoLangRadios.forEach(radio => {
            if (radio.value === this.currentLanguage) {
                radio.checked = true;
            }
        });
    }
    
    getTranslation(key) {
        return translations[this.currentLanguage]?.[key] || translations.en[key] || key;
    }
    
    // Helper method to get translation from JavaScript
    t(key) {
        return this.getTranslation(key);
    }
    
    // Format currency based on language (not needed for this version but keeping for consistency)
    formatCurrency(amount) {
        const locale = this.currentLanguage === 'fr' ? 'fr-FR' : 'en-US';
        return new Intl.NumberFormat(locale, {
            style: 'currency',
            currency: 'EUR'
        }).format(amount);
    }
    
    // Format date based on language
    formatDate(date) {
        const locale = this.currentLanguage === 'fr' ? 'fr-FR' : 'en-US';
        return new Intl.DateTimeFormat(locale, {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(new Date(date));
    }
    
    // Validate email format
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
}

// Initialize translation manager when DOM is loaded
let translationManager;

document.addEventListener('DOMContentLoaded', () => {
    translationManager = new TranslationManager();
});

// Export for use in other scripts
window.translationManager = translationManager;
window.translations = translations; 