import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { supabaseAdmin } from '@/lib/supabase'

// Initialize Stripe with secret key
const stripeSecretKey = process.env.STRIPE_SECRET_KEY
if (!stripeSecretKey) {
  throw new Error('STRIPE_SECRET_KEY environment variable is not set')
}

const stripe = new Stripe(stripeSecretKey, {
  apiVersion: '2025-06-30.basil'
})

// Webhook secret from Stripe Dashboard
const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET
if (!webhookSecret) {
  throw new Error('STRIPE_WEBHOOK_SECRET environment variable is not set')
}

export async function POST(req: NextRequest) {
  try {
    // Get the raw body as text
    const body = await req.text()
    const signature = req.headers.get('stripe-signature')!

    // Verify webhook signature
    let event: Stripe.Event
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
    } catch (err) {
      console.error('⚠️ Webhook signature verification failed:', err)
      return NextResponse.json(
        { error: 'Webhook signature verification failed' },
        { status: 400 }
      )
    }

    // Log webhook event for debugging
    if (process.env.WEBHOOK_DEBUG === 'true') {
      console.log('🔔 Webhook event received:', {
        id: event.id,
        type: event.type,
        created: new Date(event.created * 1000).toISOString()
      })
    }

    // Handle the checkout.session.completed event
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object as Stripe.Checkout.Session

      // Extract customer email from session
      const customerEmail = session.customer_details?.email || session.customer_email
      
      if (!customerEmail) {
        console.error('❌ No customer email found in session:', session.id)
        return NextResponse.json(
          { error: 'No customer email found' },
          { status: 400 }
        )
      }

      // Extract amount paid to determine credits to add
      const amountPaid = session.amount_total || 0
      const creditsToAdd = calculateCredits(amountPaid)

      if (process.env.WEBHOOK_DEBUG === 'true') {
        console.log('💳 Processing payment:', {
          sessionId: session.id,
          email: customerEmail,
          amountPaid: amountPaid / 100, // Convert from cents
          creditsToAdd
        })
      }

      // Add credits to user in Supabase
      const result = await addCreditsToUser(customerEmail, creditsToAdd, session.id)
      
      if (result.success) {
        console.log('✅ Credits successfully added:', {
          email: customerEmail,
          credits: creditsToAdd,
          sessionId: session.id
        })
        
        return NextResponse.json({
          success: true,
          message: 'Credits added successfully',
          credits: creditsToAdd
        })
      } else {
        console.error('❌ Failed to add credits:', result.error)
        return NextResponse.json(
          { error: 'Failed to add credits', details: result.error },
          { status: 500 }
        )
      }
    }

    // For other event types, just acknowledge receipt
    if (process.env.WEBHOOK_DEBUG === 'true') {
      console.log(`ℹ️ Unhandled event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })

  } catch (error) {
    console.error('❌ Webhook error:', error)
    return NextResponse.json(
      { error: 'Webhook handler failed', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

/**
 * Calculate credits based on amount paid
 * €7 = 1 credit (standard pricing)
 */
function calculateCredits(amountInCents: number): number {
  const CREDIT_PRICE_CENTS = 700 // €7 in cents
  return Math.floor(amountInCents / CREDIT_PRICE_CENTS)
}

/**
 * Add credits to user in Supabase database
 */
async function addCreditsToUser(email: string, credits: number, sessionId: string) {
  try {
    // First, try to find existing user
    const { data: existingUser, error: findError } = await supabaseAdmin
      .from('users')
      .select('id, email, credits')
      .eq('email', email.toLowerCase())
      .single()

    if (findError && findError.code !== 'PGRST116') {
      // PGRST116 is "not found" error, which is okay
      throw findError
    }

    if (existingUser) {
      // User exists, update credits
      const newCredits = existingUser.credits + credits
      
      const { data, error: updateError } = await supabaseAdmin
        .from('users')
        .update({ 
          credits: newCredits,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingUser.id)
        .select()

      if (updateError) {
        throw updateError
      }

      if (process.env.WEBHOOK_DEBUG === 'true') {
        console.log(`✅ Updated existing user ${email}: ${existingUser.credits} + ${credits} = ${newCredits} credits`)
      }

      return {
        success: true,
        user: data?.[0],
        action: 'updated'
      }
    } else {
      // User doesn't exist, create new user
      const { data, error: insertError } = await supabaseAdmin
        .from('users')
        .insert({
          email: email.toLowerCase(),
          credits: credits
        })
        .select()

      if (insertError) {
        throw insertError
      }

      if (process.env.WEBHOOK_DEBUG === 'true') {
        console.log(`✅ Created new user ${email} with ${credits} credits`)
      }

      return {
        success: true,
        user: data?.[0],
        action: 'created'
      }
    }
  } catch (error) {
    console.error('❌ Database error:', error)
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Database operation failed'
    }
  }
}

// Only allow POST requests
export async function GET() {
  return NextResponse.json(
    { error: 'Method not allowed. This endpoint only accepts POST requests.' },
    { status: 405 }
  )
} 