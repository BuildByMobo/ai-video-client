import { NextRequest, NextResponse } from 'next/server'
import { addTestCredits, getUserCredits } from '@/lib/credit-utils'

/**
 * Test endpoint to simulate webhook functionality
 * Only works in development mode
 */
export async function POST(req: NextRequest) {
  // Only allow in development
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json(
      { error: 'Test endpoint not available in production' },
      { status: 403 }
    )
  }

  try {
    const body = await req.json()
    const { email, credits = 1, action = 'add' } = body

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      )
    }

    console.log(`🧪 Test webhook: ${action} ${credits} credits for ${email}`)

    if (action === 'add') {
      const result = await addTestCredits(email, credits)
      
      if (result.success) {
        console.log('✅ Test credits added successfully:', result)
        return NextResponse.json({
          success: true,
          message: `Added ${credits} credits to ${email}`,
          result
        })
      } else {
        console.error('❌ Failed to add test credits:', result.error)
        return NextResponse.json(
          { error: 'Failed to add credits', details: result.error },
          { status: 500 }
        )
      }
    } else if (action === 'check') {
      const result = await getUserCredits(email)
      
      if (result.success) {
        return NextResponse.json({
          success: true,
          email,
          credits: result.credits,
          user: result.user
        })
      } else {
        return NextResponse.json(
          { error: 'Failed to get credits', details: result.error },
          { status: 500 }
        )
      }
    } else {
      return NextResponse.json(
        { error: 'Invalid action. Use "add" or "check"' },
        { status: 400 }
      )
    }

  } catch (error) {
    console.error('❌ Test webhook error:', error)
    return NextResponse.json(
      { error: 'Test webhook failed', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Webhook test endpoint',
    usage: {
      addCredits: 'POST /api/test-webhook with { "email": "test@example.com", "credits": 1, "action": "add" }',
      checkCredits: 'POST /api/test-webhook with { "email": "test@example.com", "action": "check" }'
    },
    note: 'Only available in development mode'
  })
} 