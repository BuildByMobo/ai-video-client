# WatAlsHetWelKan - AI Video Creation Platform

🎬 **Turn your ideas into stunning AI videos with VEO 3 technology**

A modern, multilingual web platform that allows users to generate AI videos from text prompts using advanced VEO 3 technology. Features a complete credit system, Stripe payments, and user dashboard.

![Platform Preview](https://via.placeholder.com/800x400?text=WatAlsHetWelKan+AI+Video+Platform)

## ✨ Features

### 🌍 Multilingual Support
- **English** and **French** interface
- Real-time language switching
- Localized date/currency formatting

### 💳 Payment System
- **Stripe Integration** with multiple payment methods:
  - Credit/Debit Cards
  - iDEAL (Netherlands)
  - PayPal
- Secure payment processing
- Credit-based pricing model

### 🎥 AI Video Generation
- Text-to-video using VEO 3 technology
- Multiple language support for video content
- Real-time progress tracking
- Video history and management

### 📊 User Dashboard
- Personal video library
- Credit balance management
- Video status tracking (Pending → Processing → Completed)
- Download and sharing capabilities

### 🎨 Modern UI/UX
- Responsive design (mobile-friendly)
- Clean, modern interface inspired by VEO AI
- Smooth animations and transitions
- Intuitive user experience

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn
- Stripe account (for payments)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/watalshetwelkan-ai-video.git
   cd watalshetwelkan-ai-video
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   Create a `.env` file in the root directory:
   ```env
   NODE_ENV=development
   PORT=3000
   STRIPE_PUBLISHABLE_KEY=pk_test_your_stripe_publishable_key
   STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
   STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
   FRONTEND_URL=http://localhost:3000
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to `http://localhost:3000`

## 💰 Pricing Structure

| Package | Credits | Price | Best For |
|---------|---------|-------|----------|
| Starter | 10 | €9.99 | Testing & small projects |
| **Popular** | 25 | €19.99 | Regular users |
| Pro | 50 | €34.99 | Heavy users & businesses |

## 🛠️ Technical Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with Grid/Flexbox
- **Vanilla JavaScript** - ES6+ features
- **Stripe Elements** - Secure payment forms

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **Stripe API** - Payment processing
- **In-memory storage** - Development (replace with database)

### Security & Performance
- **Helmet.js** - Security headers
- **CORS** - Cross-origin resource sharing
- **Rate limiting** - API protection
- **Compression** - Response optimization

## 📁 Project Structure

```
watalshetwelkan-ai-video/
├── index.html              # Main HTML file
├── styles.css              # Global styles
├── script.js               # Main application logic
├── translations.js         # Multilingual support
├── server.js              # Express.js backend
├── package.json           # Dependencies and scripts
├── README.md             # This file
└── .env.example          # Environment variables template
```

## 🔧 Configuration

### Stripe Setup

1. **Create a Stripe account** at [stripe.com](https://stripe.com)
2. **Get your API keys** from the Stripe Dashboard
3. **Configure webhooks** for payment confirmations
4. **Update your .env file** with the keys

### VEO API Integration

To integrate with the actual VEO API:

1. **Get VEO API credentials**
2. **Update the video generation endpoint** in `server.js`
3. **Replace the simulation** with actual API calls

```javascript
// Replace this in server.js
async function generateVideoWithVEO(prompt, language) {
    const response = await axios.post('https://api.veo.ai/v1/generate', {
        prompt,
        language,
        // Add other VEO parameters
    }, {
        headers: {
            'Authorization': `Bearer ${process.env.VEO_API_KEY}`
        }
    });
    
    return response.data;
}
```

## 🌐 API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/user/:userId` - Get user profile

### Payments
- `POST /api/payments/create-intent` - Create payment intent
- `POST /api/payments/confirm` - Confirm payment
- `POST /api/webhooks/stripe` - Stripe webhook handler

### Videos
- `POST /api/videos/generate` - Generate new video
- `GET /api/videos/user/:userId` - Get user videos
- `GET /api/videos/:videoId` - Get specific video

### Utility
- `GET /api/health` - Health check

## 🔄 Deployment

### Production Environment

1. **Environment Variables**
   ```env
   NODE_ENV=production
   PORT=443
   STRIPE_PUBLISHABLE_KEY=pk_live_your_live_key
   STRIPE_SECRET_KEY=sk_live_your_live_key
   FRONTEND_URL=https://watalshetkan.nl
   ```

2. **Database Setup**
   Replace in-memory storage with MongoDB or PostgreSQL:
   ```javascript
   // Example with MongoDB
   const mongoose = require('mongoose');
   mongoose.connect(process.env.MONGODB_URI);
   ```

3. **SSL Certificate**
   Configure HTTPS for production deployment

4. **Process Manager**
   Use PM2 for production process management:
   ```bash
   npm install -g pm2
   pm2 start server.js --name "watalshetwelkan"
   ```

### Hosting Options

- **VPS/Cloud**: DigitalOcean, AWS, Google Cloud
- **Serverless**: Vercel, Netlify (frontend) + AWS Lambda (backend)
- **Traditional**: cPanel, Plesk hosting

## 🧪 Testing

### Manual Testing Checklist

- [ ] Language switching (EN ↔ FR)
- [ ] Credit purchase flow
- [ ] Video generation process
- [ ] User registration/login
- [ ] Responsive design on mobile
- [ ] Payment processing
- [ ] Dashboard functionality

### Test Stripe Payments

Use Stripe test cards:
- **Success**: 4242 4242 4242 4242
- **Decline**: 4000 0000 0000 0002
- **3D Secure**: 4000 0025 0000 3155

## 📱 Mobile Optimization

The platform is fully responsive and optimized for:
- **iOS Safari** (iPhone/iPad)
- **Android Chrome**
- **Progressive Web App** capabilities
- **Touch-friendly** interface

## 🔐 Security Features

- **HTTPS enforcement** in production
- **CSRF protection** via Helmet.js
- **Rate limiting** to prevent abuse
- **Input validation** and sanitization
- **Secure payment processing** via Stripe
- **Environment variable** protection

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- **Email**: support@watalshetkan.nl
- **Discord**: [Join our community](https://discord.gg/watalshetwelkan)
- **Documentation**: [docs.watalshetkan.nl](https://docs.watalshetkan.nl)

## 🗺️ Roadmap

### Phase 1 (Current)
- [x] Basic video generation
- [x] Payment system
- [x] Multilingual support
- [x] User dashboard

### Phase 2 (Next)
- [ ] Real VEO API integration
- [ ] Advanced video customization
- [ ] User accounts with authentication
- [ ] Video sharing and embedding

### Phase 3 (Future)
- [ ] Collaborative features
- [ ] API for developers
- [ ] Mobile app
- [ ] Advanced analytics

---

**Made with ❤️ for the AI video generation community**

*For questions or support, reach out to the development team.* 