// WatAlsHetWelKan One-Page Video Request - EmailJS Integration
class VideoRequestApp {
    constructor() {
        this.form = null;
        this.emailJSInitialized = false;
        this.init();
    }
    
    init() {
        // Initialize EmailJS
        this.initializeEmailJS();
        
        // Setup form and event listeners
        this.setupFormElements();
        this.setupEventListeners();
        
        // Initialize UI
        this.updateCharacterCount();
        this.updateRadioButtonStyles();
    }
    
    initializeEmailJS() {
        // Initialize EmailJS
        // 🔧 SETUP REQUIRED: Replace these with your actual EmailJS credentials
        // 1. Go to https://www.emailjs.com/
        // 2. Create an account and get your credentials
        // 3. Replace the values below:
        
        const emailJSConfig = {
            userId: 'qcds8_GjBOXwzPxJ5',        // Your real EmailJS User ID
            serviceId: 'service_vfrjb2o',        // Your working Service ID  
            templateId: 'template_11l31s8' // The working Template ID from your history
        };
        
        try {
            // Check if EmailJS is loaded
            if (typeof emailjs === 'undefined') {
                console.error('❌ EmailJS SDK not loaded. Check if script tag is correct.');
                this.emailJSInitialized = false;
                return;
            }
            
            // For development/demo - use dummy config to prevent errors
            if (emailJSConfig.userId === 'YOUR_EMAILJS_USER_ID') {
                console.log('📧 EmailJS Setup Required:');
                console.log('1. Sign up at https://www.emailjs.com/');
                console.log('2. Get your User ID, Service ID, and Template ID');
                console.log('3. Replace the placeholder values in script.js');
                console.log('4. Create a template with variables: user_email, video_language, video_prompt, from_name');
                
                // For demo purposes, we'll simulate EmailJS functionality
                this.emailJSInitialized = false;
            } else {
                // Initialize EmailJS with real credentials
                console.log('🔧 Initializing EmailJS with credentials:', {
                    userId: emailJSConfig.userId,
                    serviceId: emailJSConfig.serviceId,
                    templateId: emailJSConfig.templateId
                });
                
                emailjs.init(emailJSConfig.userId);
                this.emailJSConfig = emailJSConfig;
                this.emailJSInitialized = true;
                console.log('✅ EmailJS initialized successfully');
            }
        } catch (error) {
            console.error('❌ EmailJS initialization failed:', error);
            this.emailJSInitialized = false;
        }
    }
    
    setupFormElements() {
        this.form = document.getElementById('videoForm');
        this.emailInput = document.getElementById('userEmail');
        this.promptInput = document.getElementById('videoPrompt');
        this.submitBtn = document.getElementById('submitBtn');
        this.submitText = document.getElementById('submitText');
        this.loadingText = document.getElementById('loadingText');
        this.charCount = document.getElementById('charCount');
        this.successMessage = document.getElementById('successMessage');
        this.errorMessage = document.getElementById('errorMessage');
    }
    
    setupEventListeners() {
        // Form submission
        if (this.form) {
            this.form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleFormSubmit();
            });
        }
        
        // Character counting for prompt
        if (this.promptInput) {
            this.promptInput.addEventListener('input', () => {
                this.updateCharacterCount();
            });
            
            // Auto-resize textarea
            this.promptInput.addEventListener('input', this.autoResizeTextarea);
        }
        
        // Email validation
        if (this.emailInput) {
            this.emailInput.addEventListener('blur', () => {
                this.validateEmail();
            });
        }
        
        // Radio button styling
        const radioButtons = document.querySelectorAll('input[name="videoLanguage"]');
        radioButtons.forEach(radio => {
            radio.addEventListener('change', () => {
                this.updateRadioButtonStyles();
            });
        });
        
        // Real-time form validation
        [this.emailInput, this.promptInput].forEach(input => {
            if (input) {
                input.addEventListener('input', () => {
                    this.validateForm();
                });
            }
        });
    }
    
    updateCharacterCount() {
        if (this.promptInput && this.charCount) {
            const count = this.promptInput.value.length;
            this.charCount.textContent = count;
            
            // Color coding for character count
            if (count > 450) {
                this.charCount.style.color = '#dc2626'; // red
            } else if (count > 350) {
                this.charCount.style.color = '#d97706'; // orange
            } else {
                this.charCount.style.color = '#9ca3af'; // gray
            }
        }
    }
    
    autoResizeTextarea(e) {
        e.target.style.height = 'auto';
        e.target.style.height = Math.min(e.target.scrollHeight, 200) + 'px';
    }
    
    updateRadioButtonStyles() {
        // With the new design using peer-checked, this function is less needed
        // but we'll keep it for any additional styling if needed
        const radioButtons = document.querySelectorAll('input[name="videoLanguage"]');
        radioButtons.forEach(radio => {
            // The new CSS with peer-checked handles the styling automatically
            // This function can be extended later if needed for additional effects
        });
    }
    
    validateEmail() {
        if (!this.emailInput) return true;
        
        const email = this.emailInput.value.trim();
        
        // Simple email validation regex
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const isValid = email && emailRegex.test(email);
        
        if (email && !isValid) {
            this.showFieldError(this.emailInput, window.translationManager?.t('email_invalid') || 'Invalid email');
            return false;
        } else {
            this.clearFieldError(this.emailInput);
            return true;
        }
    }
    
    validatePrompt() {
        if (!this.promptInput) return true;
        
        const prompt = this.promptInput.value.trim();
        const length = prompt.length;
        
        if (!prompt) {
            this.showFieldError(this.promptInput, window.translationManager?.t('prompt_required') || 'Prompt required');
            return false;
        } else if (length > 500) {
            this.showFieldError(this.promptInput, window.translationManager?.t('prompt_too_long') || 'Too long');
            return false;
        } else {
            this.clearFieldError(this.promptInput);
            return true;
        }
    }
    
    validateForm() {
        const emailValid = this.validateEmail();
        const promptValid = this.validatePrompt();
        const isValid = emailValid && promptValid;
        
        if (this.submitBtn) {
            this.submitBtn.disabled = !isValid;
        }
        
        return isValid;
    }
    
    showFieldError(field, message) {
        field.classList.add('border-red-300', 'focus:border-red-500');
        field.classList.remove('border-gray-200', 'focus:border-primary-500');
        
        // Remove existing error message
        const existingError = field.parentNode.querySelector('.field-error');
        if (existingError) {
            existingError.remove();
        }
        
        // Add new error message
        const errorEl = document.createElement('p');
        errorEl.className = 'field-error text-sm text-red-600 mt-1';
        errorEl.textContent = message;
        field.parentNode.appendChild(errorEl);
    }
    
    clearFieldError(field) {
        field.classList.remove('border-red-300', 'focus:border-red-500');
        field.classList.add('border-gray-200', 'focus:border-primary-500');
        
        const errorEl = field.parentNode.querySelector('.field-error');
        if (errorEl) {
            errorEl.remove();
        }
    }
    
    async handleFormSubmit() {
        // Hide previous messages
        this.hideMessages();
        
        // Validate form
        if (!this.validateForm()) {
            this.showError(window.translationManager?.t('error_message') || 'Please check your input');
            return;
        }
        
        // Show loading state
        this.setLoadingState(true);
        
        try {
            // Get form data
            const formData = this.getFormData();
            
            // Send email via EmailJS
            if (this.emailJSInitialized) {
                await this.sendEmailJS(formData);
            } else {
                // Demo mode - simulate sending
                await this.simulateEmailSend(formData);
            }
            
            // Show success
            this.showSuccess();
            this.resetForm();
            
        } catch (error) {
            console.error('Form submission error:', error);
            this.showError(error.message || (window.translationManager?.t('emailjs_error') || 'Failed to send request'));
        } finally {
            this.setLoadingState(false);
        }
    }
    
    getFormData() {
        const videoLanguage = document.querySelector('input[name="videoLanguage"]:checked')?.value || 'en';
        const userEmail = this.emailInput?.value.trim() || '';
        const videoPrompt = this.promptInput?.value.trim() || '';
        
        return {
            user_email: userEmail,
            video_language: videoLanguage,
            video_prompt: videoPrompt,
            from_name: userEmail.split('@')[0], // Use email username as name
            request_date: new Date().toLocaleString(),
            user_language: window.translationManager?.currentLanguage || 'en'
        };
    }
    
    async sendEmailJS(formData) {
        if (!this.emailJSInitialized) {
            console.error('❌ EmailJS not initialized');
            throw new Error('EmailJS not properly configured');
        }
        
        console.log('📧 Sending email with data:', formData);
        console.log('📧 Using service:', this.emailJSConfig.serviceId);
        console.log('📧 Using template:', this.emailJSConfig.templateId);
        
        try {
            const response = await emailjs.send(
                this.emailJSConfig.serviceId,
                this.emailJSConfig.templateId,
                formData
            );
            
            console.log('✅ Email sent successfully:', response);
            return response;
        } catch (error) {
            console.error('❌ EmailJS send failed:', error);
            console.error('❌ Error details:', {
                message: error.message,
                text: error.text,
                status: error.status
            });
            
            if (error.text) {
                throw new Error(`EmailJS Error: ${error.text}`);
            } else if (error.status) {
                throw new Error(`EmailJS Error (${error.status}): ${error.message}`);
            } else {
                throw new Error(`Network Error: ${error.message}`);
            }
        }
    }
    
    async simulateEmailSend(formData) {
        // Demo mode - simulate email sending
        console.log('📧 Demo Mode - Email would be sent with data:', formData);
        
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Simulate occasional failure for demo
        if (Math.random() < 0.1) {
            throw new Error('Demo: Simulated network error');
        }
        
        console.log('✅ Demo: Email sent successfully');
    }
    
    setLoadingState(loading) {
        if (!this.submitBtn || !this.submitText || !this.loadingText) return;
        
        this.submitBtn.disabled = loading;
        
        if (loading) {
            this.submitText.classList.add('hidden');
            this.loadingText.classList.remove('hidden');
            this.submitBtn.classList.add('opacity-75');
        } else {
            this.submitText.classList.remove('hidden');
            this.loadingText.classList.add('hidden');
            this.submitBtn.classList.remove('opacity-75');
        }
    }
    
    showSuccess() {
        if (this.successMessage) {
            this.successMessage.classList.remove('hidden');
            this.successMessage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }
    
    showError(message) {
        if (this.errorMessage) {
            // Update error message text
            const errorText = this.errorMessage.querySelector('[data-translate="error_message"]');
            if (errorText) {
                errorText.textContent = message;
            }
            
            this.errorMessage.classList.remove('hidden');
            this.errorMessage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }
    
    hideMessages() {
        if (this.successMessage) {
            this.successMessage.classList.add('hidden');
        }
        if (this.errorMessage) {
            this.errorMessage.classList.add('hidden');
        }
    }
    
    resetForm() {
        if (this.form) {
            this.form.reset();
            this.updateCharacterCount();
            this.updateRadioButtonStyles();
            
            // Clear any field errors
            [this.emailInput, this.promptInput].forEach(input => {
                if (input) {
                    this.clearFieldError(input);
                }
            });
            
            // Reset to interface language
            if (window.translationManager) {
                const currentLang = window.translationManager.currentLanguage;
                const radioToCheck = document.querySelector(`input[name="videoLanguage"][value="${currentLang}"]`);
                if (radioToCheck) {
                    radioToCheck.checked = true;
                    this.updateRadioButtonStyles();
                }
            }
        }
    }
}

// Utility function to show toast notifications
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `fixed top-4 right-4 z-50 px-6 py-4 rounded-lg shadow-lg text-white transform transition-all duration-300 translate-x-full ${
        type === 'success' ? 'bg-green-500' : 
        type === 'error' ? 'bg-red-500' : 
        'bg-blue-500'
    }`;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    // Animate in
    setTimeout(() => {
        toast.classList.remove('translate-x-full');
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        toast.classList.add('translate-x-full');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 4000);
}

// Initialize app when DOM is loaded
let videoRequestApp;

document.addEventListener('DOMContentLoaded', () => {
    videoRequestApp = new VideoRequestApp();
    
    // Show setup instructions if EmailJS not configured
    setTimeout(() => {
        if (!videoRequestApp.emailJSInitialized) {
            console.log('\n🔧 EmailJS Setup Instructions:');
            console.log('================================');
            console.log('1. Go to https://www.emailjs.com/');
            console.log('2. Create a free account');
            console.log('3. Create an email service (Gmail, Outlook, etc.)');
            console.log('4. Create an email template with these variables:');
            console.log('   - {{user_email}} - Customer email');
            console.log('   - {{video_language}} - Video language choice');
            console.log('   - {{video_prompt}} - Video description');
            console.log('   - {{from_name}} - Customer name');
            console.log('   - {{request_date}} - Request timestamp');
            console.log('5. Get your User ID, Service ID, and Template ID');
            console.log('6. Replace the placeholder values in script.js');
            console.log('\nCurrently running in DEMO MODE - form submissions are simulated.');
        }
    }, 1000);
});

// Export for global access
window.videoRequestApp = videoRequestApp;

// EmailJS Template Example:
/*
Subject: New AI Video Request from {{from_name}}

Hello,

You have received a new AI video request:

Customer Email: {{user_email}}
Video Language: {{video_language}}
Request Date: {{request_date}}

Video Description:
{{video_prompt}}

Please process this request and contact the customer within 24 hours.

Best regards,
WatAlsHetWelKan System
*/ 